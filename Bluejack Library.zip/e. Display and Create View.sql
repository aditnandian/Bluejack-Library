--e). 

--1. Display StudentName, StudentAddress, BorrowTransactionID, BorrowTransactionDate, 
--   and number of books borrowed (obtained from the total number of books borrowed) 
--   for every borrow transaction happened in 2020 by student whose address ends with � Street�.

SELECT
	[StudentName] = student_name,
	[StudentAddress] = student_address,
	[BorrowTransactionID] = BT.borrow_id,
	[BorrowTransactionDate] = borrow_date,
	[Number of Books Borrowed] = COUNT(book_id)
FROM Student ST 
	JOIN BorrowTransaction BT
	ON ST.student_id = BT.student_id
	JOIN BorrowTransactionDetail BTD
	ON BT.borrow_id = BTD.borrow_id
WHERE YEAR(borrow_date) = '2020' AND student_address LIKE '% Street'
GROUP BY student_name, student_address, BT.borrow_id, borrow_date

--2. Display BookTitle, Publish Month (obtained from the month of the book publish date), BookCategoryName, 
--	 and Total Sum Donation (obtained from the total donation quantity) for each book whose category name 
--   contains �y� and published in an odd month. 

SELECT 
	[BookTitle] = book_title,
	[Publish Month] = MONTH(publish_date),
	[BookCategoryName] = category,
	[Total Sum Donation] = SUM(quantity)
FROM Book BK
	JOIN DonationTransactionDetail DT
	ON BK.book_id = DT.book_id
	JOIN BookCategories BC
	ON BK.book_category_id = BC.book_category_id
WHERE (category LIKE 'y%' OR category LIKE '%y%' OR category LIKE '%y') AND MONTH(publish_date) % 2 != 0
GROUP BY book_title, publish_date, category

-- 3. Display BorrowTransactionID, Borrow Transaction Date (obtained from BorrowTransactionDate with �dd mon yyyy� format), 
--    StudentName, Books Borrowed (obtained from the total number of borrowed books), and Average Book Rating (obtained from 
--    the average rating of borrowed books) for every borrow transaction whose student has �gmail� domain email and Average Book Rating more than 4.0.

SELECT 
	[BorrowTransactionID] = BT.borrow_id,
	[Borrow Transaction Date] = CONVERT(VARCHAR,borrow_date,106),
	[StudentName] = student_name,
	[Books Borrowed] = COUNT(BTD.book_id), 
	[Average Book Rating] = AVG(rating)
FROM BorrowTransaction BT 
	JOIN Student ST
	ON BT.student_id = ST.student_id
	JOIN BorrowTransactionDetail BTD
	ON BT.borrow_id = BTD.borrow_id
	JOIN Book BK
	ON BTD.book_id = BK.book_id
WHERE student_email LIKE '%gmail%'
GROUP BY BT.borrow_id, borrow_date, student_name
HAVING AVG(rating) > 4.0

-- 4. Display DonatorName (obtained from DonatorName and started with �Ms.�), DonationDate (obtained from DonationDate with �Mon dd, yyyy� format), 
--    Books Donated (obtained from the number of donated books), and Average Rating (obtained from the average rating of the donated books) for each 
--    donation happened in the first two weeks (inclusively between the 1st and the 14th day) from a female donator. 

SELECT
	[DonatorName] = 'Ms.' + donator_name,
	[DonationDate] = CONVERT(VARCHAR,donation_date,107),
	[Books Donated] = COUNT( DISTINCT quantity),
	[Average Rating] = AVG(rating)
FROM Donator DR
	JOIN DonationTransaction DT
	ON DR.donator_id = DT.donator_id
	JOIN DonationTransactionDetail DTD
	ON DT.donation_id = DTD.donation_id
	JOIN Book BK
	ON DTD.book_id = BK.book_id
WHERE donation_date BETWEEN '2020-07-10' AND '2020-07-24' AND donator_gender LIKE 'Female'
GROUP BY donator_name, donation_date

-- 5. Display DonatorName, DonationDate, StaffName, StaffGender, and StaffSalary (obtained from StaffSalary and started with �Rp.�) 
--    for every donation completed by staff whose salary is more than the average staff salary and its donator name consists of minimum 
--    two words. Sort the result by DonationDate in descending order. 
--    (alias subquery)

SELECT
	[DonatorName] = DR.donator_name,
	[DonationDate] = donation_date,
	[StaffName] = staff_name,
	[StaffGender] = staff_gender,
	[StaffSalary] = 'Rp.' + CONVERT(VARCHAR,staff_salary)
FROM Donator DR
	JOIN DonationTransaction DT
	ON DR.donator_id = DT.donator_id
	JOIN Staff SF
	ON DT.staff_id = SF.staff_id,
	(SELECT Average = AVG(staff_salary) FROM Staff)	AS A,
	(SELECT donator_name AS DonatorCheck
	 FROM Donator
	 WHERE donator_name LIKE '% %'
	 ) AS B	
WHERE staff_salary > A.Average AND DR.donator_name = B.DonatorCheck
ORDER BY donation_date DESC

--6. Display DonationID, BookTitle (obtained from removing all white spaces from BookTitle), Rating Percentage (obtained from multiplying 
--   the BookRating with 20 and added with �%� at the end), Quantity, and DonatorPhone for each donation with book rating more than the average 
--   rating and DonatorAddress consists of more than 15 characters. 
--   (alias subquery)

SELECT DISTINCT
	[DonationID] = DT.donation_id,
	[BookTitle] = book_title,
	[Rating Percentage] = CONVERT(VARCHAR, (20*rating)) + '%',
	[Quantity] = quantity,
	[DonatorPhone] = donator_phone_number
FROM DonationTransaction DT
	JOIN DonationTransactionDetail DTD
	ON DT.donation_id = DTD.donation_id
	JOIN Book BK
	ON DTD.book_id = BK.book_id
	JOIN Donator DR
	ON DT.donator_id = DR.donator_id,
	(SELECT AVG(rating) AS Average FROM Book) AS A,
	(SELECT donator_address AS DonatorAddressCheck
	 FROM Donator
	 WHERE LEN(donator_address) > 15
	 ) AS B	
WHERE rating > A.Average AND donator_address = B.DonatorAddressCheck

--7. Display BorrowTransactionID, Borrow Date (obtained from BorrowTransactionDate in �mm-dd-yyyy� format), 
--   Return Day (obtained from the day name of the return date), BookTitle, BookRating (obtained from BookRating followed by � star(s)�), 
--   and BookCategoryName for each borrow transaction which contains book(s) whose rating is equal to the minimum rating or the maximum 
--   rating of all available books while also have more than 10 stocks. Sort the result based on the BorrowTransactionID in descending order.
--   (alias subquery)

SELECT 
	[BorrowTransactionID] = BT.borrow_id,
	[Borrow Date] = CONVERT(VARCHAR,borrow_date,110),
	[Return Day] = DAY(borrow_date),
	[BookTitle] = book_title,
	[BookRating] = CONVERT(VARCHAR,rating) + ' star(s)',
	[BookCategoryName] = category
FROM BorrowTransaction BT
	JOIN BorrowTransactionDetail BTD
	ON BT.borrow_id = BTD.borrow_id
	JOIN Book BK
	ON BTD.book_id = BK.book_id
	JOIN BookCategories BC
	ON BK.book_category_id = BC.book_category_id,
	(SELECT MAX(rating) AS MaxRating FROM Book WHERE stock>10) AS A,
	(SELECT MIN(rating) AS MinRating FROM Book WHERE stock>10) AS B
WHERE rating = A.MaxRating OR rating = B.MinRating
ORDER BY BT.borrow_id DESC

--8 Display StudentName (obtained from StudentName added with �Mr. � at the beginning), StudentEmail (obtained by removing �.com� from StudentEmail), 
--  Books Borrowed (obtained from the total number of books borrowed) for each borrow transaction done by male student and served by staff whose salary 
--  is more than the average staff salary. Then, combine it with StudentName (obtained from StudentName added with �Ms. � at the beginning), 
--  StudentEmail (obtained by removing �.com� from StudentEmail), Books Borrowed (obtained from the total number of books borrowed) for each borrow transaction 
--  done by female student and served by staff whose salary is less than the average staff salary.
--  (alias subquery)

SELECT 
	[StudentName] = 'Mr. ' + student_name,
	[StudentEmail] = SUBSTRING(student_email, 1, LEN(student_email) - 4),
	[Books Borrowed] = COUNT(DISTINCT book_id)
FROM Student ST
	JOIN BorrowTransaction BT
	ON ST.student_id = BT.student_id
	JOIN BorrowTransactionDetail BTD
	ON BT.borrow_id = BTD.borrow_id
	JOIN Staff SF
	ON SF.staff_id = BT.staff_id,
	(SELECT student_gender AS GenderCheck
	 FROM Student
	 WHERE student_gender LIKE 'Male'
	 ) AS A,
	(SELECT AVG(staff_salary) AS Average FROM Staff) AS B
WHERE student_gender = A.GenderCheck AND staff_salary > B.Average
GROUP BY student_name, student_email
	UNION
SELECT 
	[StudentName] = 'Ms. ' + student_name,
	[StudentEmail] = SUBSTRING(student_email, 1, LEN(student_email) - 4),
	[Books Borrowed] = COUNT(DISTINCT book_id)
FROM Student ST
	JOIN BorrowTransaction BT
	ON ST.student_id = BT.student_id
	JOIN BorrowTransactionDetail BTD
	ON BT.borrow_id = BTD.borrow_id
	JOIN Staff SF
	ON SF.staff_id = BT.staff_id,
	(SELECT student_gender AS GenderCheck
	 FROM Student
	 WHERE student_gender LIKE 'Female'
	 ) AS A,
	(SELECT AVG(staff_salary) AS Average FROM Staff) AS B
WHERE student_gender = A.GenderCheck AND staff_salary < B.Average
GROUP BY student_name, student_email

-- 9. Create a view named �ViewDonationDetail� to display DonatorName, Donation Transaction (obtained from the number of donation transaction), 
--    Average Quantity (obtained from the average donation quantity) for each donation done by donator whose address ended with � Street� or � Avenue� 
--    and Donation Transaction more than 1.
GO
CREATE VIEW ViewDonationDetail
AS
SELECT
	[Donation Transaction] = COUNT(DISTINCT DT.donation_id),
	[Average Quantity] = AVG(quantity)
FROM DonationTransaction DT
	JOIN DonationTransactionDetail DTD
	ON DT.donation_id = DTD.donation_id
	JOIN Donator DR
	ON DR.donator_id = DT.donator_id,
	(SELECT donator_address AS AddressCheck
	 FROM Donator
	 WHERE donator_address LIKE '% Street' OR donator_address LIKE '% Avenue'
	 ) AS A
WHERE donator_address = A.AddressCheck
HAVING COUNT(DISTINCT DT.donation_id) > 1


-- 10. Create a view named �ViewStudentBorrowingData� to display StudentName, Borrow Transaction (obtained from the total number of transaction), 
--     and Average Duration (obtained from the average different days between the borrow date and return date) for each borrow transaction done by 
--     male student whose email contains �yahoo�.
GO
CREATE VIEW ViewStudentBorrowingData
AS
SELECT 
	[StudentName] = student_name,
	[Borrow Transaction] = COUNT(DISTINCT BT.borrow_id),
	[Average Duration] = AVG(DATEDIFF(DAY,borrow_date,return_date))
FROM Student ST
	JOIN BorrowTransaction BT
	ON ST.student_id = BT.student_id
	JOIN BorrowTransactionDetail BTD
	ON BT.borrow_id = BTD.borrow_id,
	(SELECT student_gender AS StudentCheck
	 FROM Student
	 WHERE student_gender LIKE 'Male'
	 ) AS A
WHERE student_gender = A.StudentCheck AND student_email LIKE '%yahoo%'
GROUP BY student_name