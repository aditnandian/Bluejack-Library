CREATE DATABASE Bluejack_Library

USE Bluejack_Library

--b).
CREATE TABLE Staff(
	staff_id CHAR(5) PRIMARY KEY NOT NULL,
	staff_name VARCHAR(50) NOT NULL,
	staff_gender VARCHAR(20) NOT NULL,
	staff_address VARCHAR(50) NOT NULL,
	staff_phone VARCHAR(15) NOT NULL,
	staff_salary INT NOT NULL,
	CONSTRAINT CheckStaffID CHECK(staff_id LIKE 'SF[0-9][0-9][0-9]'),
	CONSTRAINT CheckStaffGender CHECK(staff_gender = 'Male' OR staff_gender = 'Female' ),
	CONSTRAINT CheckStaffPhone CHECK(staff_phone LIKE '+62%')
);

CREATE TABLE Donator (
	donator_id CHAR(5) PRIMARY KEY NOT NULL,
	donator_name VARCHAR(50) NOT NULL,
	donator_gender VARCHAR(20) NOT NULL,
	donator_address VARCHAR(50) NOT NULL,
	donator_phone_number VARCHAR(15) NOT NULL,
	CONSTRAINT CheckDonatorID CHECK(donator_id LIKE 'DR[0-9][0-9][0-9]'),
	CONSTRAINT CheckDonatorName CHECK(LEN(donator_name) > 1)
);

CREATE TABLE Student(
	student_id CHAR(5) PRIMARY KEY NOT NULL,
	student_name VARCHAR(50) NOT NULL,
	student_gender VARCHAR(20) NOT NULL,
	student_address VARCHAR(50) NOT NULL,
	student_email VARCHAR(50) NOT NULL,
	CONSTRAINT CheckStudentID CHECK(student_id LIKE 'ST[0-9][0-9][0-9]'),
	CONSTRAINT CheckStudentGender CHECK(student_gender = 'Male' OR student_gender = 'Female' ),
	CONSTRAINT CheckStudentEmail CHECK(student_email LIKE '%@%')
);

CREATE TABLE BookCategories (
	book_category_id CHAR(5) PRIMARY KEY NOT NULL,
	category VARCHAR(20) NOT NULL,
	CONSTRAINT CheckBookCategoriesID CHECK(book_category_id LIKE 'BC[0-9][0-9][0-9]')
);

CREATE TABLE Book(
	book_id CHAR(5) PRIMARY KEY NOT NULL,
	book_category_id CHAR(5) FOREIGN KEY (book_category_id) REFERENCES BookCategories (book_category_id) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	book_title VARCHAR(50) NOT NULL,
	publish_date DATE NOT NULL,
	stock INT NOT NULL,
	rating FLOAT NOT NULL,
	CONSTRAINT CheckBookID CHECK(book_id LIKE 'BK[0-9][0-9][0-9]'),
	CONSTRAINT CheckBookPublishYear CHECK (YEAR(publish_date) > 2011)
);

CREATE TABLE BorrowTransaction(
	borrow_id CHAR(5) PRIMARY KEY NOT NULL,
	student_id CHAR(5) FOREIGN KEY (student_id) REFERENCES Student (student_id) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	staff_id CHAR(5) FOREIGN KEY (staff_id) REFERENCES Staff (staff_id) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	borrow_date DATE NOT NULL,
	CONSTRAINT CheckBorrowTransactionID CHECK(borrow_id LIKE 'BT[0-9][0-9][0-9]')
);

CREATE TABLE BorrowTransactionDetail(
	borrow_id CHAR(5) FOREIGN KEY REFERENCES BorrowTransaction(borrow_id) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	book_id CHAR(5) FOREIGN KEY (book_id) REFERENCES Book (book_id) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	return_date DATE NOT NULL,
	PRIMARY KEY(borrow_id, book_id),
	CONSTRAINT CheckReturnDate CHECK(return_date > GETDATE())
);

CREATE TABLE DonationTransaction(
	donation_id CHAR(5) PRIMARY KEY NOT NULL,
	staff_id CHAR(5) FOREIGN KEY (staff_id) REFERENCES Staff (staff_id) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	donator_id CHAR(5) FOREIGN KEY (donator_id) REFERENCES Donator (donator_id) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	donation_date DATE NOT NULL,
	CONSTRAINT CheckDonationTransactionID CHECK(donation_id LIKE 'DT[0-9][0-9][0-9]'),
);

CREATE TABLE DonationTransactionDetail(
	donation_id CHAR(5) FOREIGN KEY REFERENCES DonationTransaction(donation_id) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	book_id CHAR(5) FOREIGN KEY (book_id) REFERENCES Book (book_id) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	quantity INT NOT NULL,
	PRIMARY KEY(donation_id, book_id),
	CONSTRAINT CheckQuantity CHECK(quantity BETWEEN 10 AND 500)
);

--c).

INSERT INTO Staff VALUES
('SF001', 'Rahayu', 'Female', 'Jl. Garuda No.12', '+6281322367875', 1000000),
('SF002', 'Jerome Polin', 'Male', 'Jl. Sultan Iskandar 155A', '+6289087656987', 2000000),
('SF003', 'Keanu Angelo', 'Male', 'Jl. Cut Nyak Dien 200B', '+6281223432227', 2030000),
('SF004', 'Fujiyanti', 'Female', 'Jl. Diponegoro no. 2 ', '+6281223432228', 1930000),
('SF005', 'Gaga Muhammad', 'Male', 'Jl. Keanu no. 25 ', '+6281224567890', 1220000),
('SF006', 'Nian Pramadani', 'Female', 'Jl. Manggis 33D ', '+6281223432743', 1220000),
('SF007', 'Ahmad Dhani', 'Male', 'Jl. Ariana Grande no.12 ', '+6289923432741', 1020000),
('SF008', 'Mulan Jameela', 'Female', 'Jl. Selena Gomex no.5B ', '+6281223876997', 3420000),
('SF009', 'Mulan Jameela Jamilati', 'Female', 'Jl. Charlie no.44 ', '+6282424276997', 5530000),
('SF010', 'Adigang Adigung Adiguna', 'Male', 'Jl. Golf 121B ', '+6287885990998', 2150000);

INSERT INTO Donator VALUES
('DR001', 'Bambang Hariyadi', 'Male', 'Aba No.111 Street', '081224789008'),
('DR002', 'Muklis Priambuda', 'Male', 'Jl. Mahakam 112A', '081222222889'),
('DR003', 'Mukmin Priambuda', 'Male', 'Halmahera 112A Avenue', '081333222889'),
('DR004', 'Muklis Priambuda Solihin', 'Male', 'Jl. Musi 3A', '081222222886'),
('DR005', 'Jonathan', 'Male', 'Jl. Badak No.5', '089887890996'),
('DR006', 'Mimi', 'Female', 'Jl. Badak No.5', '0898878909123'),
('DR007', 'Clara Evangelina', 'Female', 'Jl. Rusa No.3', '0898878909321'),
('DR008', 'Mark Zukcuruask', 'Male', 'Zukcuruask  No.34 Street', '0898878911111'),
('DR009', 'Zeline Zukcuruask', 'Female', 'Zukcuruask  No.34 Street', '0898878922222'),
('DR010', 'Laura Zukcuruask', 'Female', 'Zukcuruask  Avenue', '0898878933333');

INSERT INTO Student VALUES
('ST001', 'Trimardi Aditya', 'Male', 'Domba No.77B Avenue', 'trimardi1213313@yahoo.com'),
('ST002', 'John Swavorski', 'Male', 'Bebek No.78B Street', 'secretagent1@gmail.com'),
('ST003', 'John Swavorski', 'Female', 'Angsa No.78B Street', 'secretagent2@yahoo.com'),
('ST004', 'John Swavorski', 'Male', 'Jl. Ayam No.78B', 'secretagent3@gmail.com'),
('ST005', 'Rainych', 'Female', 'Jl. Ayam No.78B Avenue', 'rainychan@gmail.com'),
('ST006', 'Shizuka Arigatou', 'Female', 'Nobita no.12 Street', 'shizukaarigatou@yahoo.com'),
('ST007', 'Naomi Kamshamida', 'Female', 'Kamshamida no.78 Street', 'naomikamshamida@rocketmail.com'),
('ST008', 'Ariana Thank You', 'Female', 'Jl. Lingkar Dalam Utara no.2', 'thankyouariana@gmail.com'),
('ST009', 'Sugeng Rawuh', 'Male', 'Lingkar Dalam Barat Avenue', 'sugengrawuh@yahoo.com'),
('ST010', 'Jonathan Binus Kurniawan', 'Male', 'Jl. Lingkar Dalam Barat no.4', 'jonathanbinuskurniawan@gmail.com');

INSERT INTO BookCategories VALUES
('BC001', 'Fantasy'),
('BC002', 'Mystery'),
('BC003', 'Education'),
('BC004', 'Romance'),
('BC005', 'Sci-fi');

INSERT INTO Book VALUES
('BK001', 'BC001', 'The Magical Cave', '2020-01-03' , 146, 7.0),
('BK002', 'BC002', 'Misteri Terbesar Dunia', '2015-08-10', 23, 6.0),
('BK003', 'BC003', 'Fisika Kuantum', '2020-03-13', 43, 6),
('BK004', 'BC004', 'Cintaku Bersemi di Alam Sutera', '2020-07-27', 21, 4.5),
('BK005', 'BC005', 'The Last Breath', '2018-06-19', 58, 8.0),
('BK006', 'BC001', 'Journey to The West', '2019-02-20', 84, 5.0),
('BK007', 'BC002', 'Sherlock Holmes Baker Street Edition', '2013-10-24', 61, 7.0),
('BK008', 'BC003', 'C Programming Language', '2013-08-16', 41, 7.0),
('BK009', 'BC004', 'The Wedding', '2016-12-12', 300, 4.0),
('BK010', 'BC005', 'The Ash', '2012-04-08', 91, 9.0),
('BK011', 'BC001', 'Dragon and The Magic Wings', '2012-06-03', 33, 4.0),
('BK012', 'BC002', 'Misteri Jalan KM 98', '2020-09-10', 22, 3.0),
('BK013', 'BC003', 'Metaverse 2035', '2021-01-05', 40, 3.0),
('BK014', 'BC004', 'The Night After', '2019-08-04', 78, 7.0),
('BK015', 'BC005', 'Black Hole', '2015-11-30', 93, 9.5),
('BK016', 'BC001', 'Percy Jackson and The Dwarfs', '2019-11-10', 23, 9.0),
('BK017', 'BC002', 'Black Hole', '2018-12-12', 33, 5.5);

INSERT INTO DonationTransaction (donation_id, donator_id, staff_id, donation_date)
VALUES 
('DT001', 'DR001', 'SF009', '2021-04-28'),
('DT002', 'DR001', 'SF006', '2021-04-29'),
('DT003', 'DR002', 'SF006', '2021-05-10'),
('DT004', 'DR001', 'SF001', '2021-05-15'),
('DT005', 'DR003', 'SF004', '2021-05-17'),
('DT006', 'DR004', 'SF002', '2021-05-28'),
('DT007', 'DR004', 'SF002', '2021-05-29'),
('DT008', 'DR005', 'SF006', '2021-06-16'),
('DT009', 'DR005', 'SF006', '2021-06-19'),
('DT010', 'DR009', 'SF006', '2021-06-25'),
('DT011', 'DR002', 'SF003', '2021-08-25'),
('DT012', 'DR006', 'SF010', '2021-09-09'),
('DT013', 'DR007', 'SF005', '2021-11-04'),
('DT014', 'DR008', 'SF005', '2021-11-11'),
('DT015', 'DR010', 'SF007', '2021-12-12'),
('DT016', 'DR006', 'SF007', '2020-07-10'),
('DT017', 'DR009', 'SF007', '2020-07-13'),
('DT018', 'DR009', 'SF007', '2020-07-22');

INSERT INTO DonationTransactionDetail (donation_id, quantity, book_id)
VALUES
('DT001', 26, 'BK001'),
('DT002', 23, 'BK002'),
('DT003', 21, 'BK003'),
('DT004', 22, 'BK003'),
('DT005', 21, 'BK004'),
('DT006', 27, 'BK005'),
('DT007', 31, 'BK005'),
('DT008', 28, 'BK006'),
('DT009', 28, 'BK006'),
('DT010', 28, 'BK006'),
('DT011', 28, 'BK006'),
('DT011', 21, 'BK007'),
('DT011', 41, 'BK008'),
('DT012', 21, 'BK007'),
('DT012', 100, 'BK009'),
('DT013', 21, 'BK007'),
('DT013', 100, 'BK009'),
('DT013', 41, 'BK010'),
('DT014', 100, 'BK009'),
('DT014', 50, 'BK010'),
('DT014', 33, 'BK011'),
('DT015', 22, 'BK012'),
('DT015', 40, 'BK013'),
('DT015', 78, 'BK014'),
('DT015', 93, 'BK015'),
('DT015', 23, 'BK016'),
('DT015', 33, 'BK017'),
('DT016', 30, 'BK001'),
('DT017', 40, 'BK001'),
('DT018', 50, 'BK001');

INSERT INTO BorrowTransaction (borrow_id, staff_id, student_id, borrow_date)
VALUES
('BT001', 'SF008', 'ST001', '2021-12-20'),
('BT002', 'SF008', 'ST002', '2021-12-21'),
('BT003', 'SF002', 'ST004', '2021-12-22'),
('BT004', 'SF001', 'ST002', '2021-12-23'),
('BT005', 'SF002', 'ST008', '2021-12-24'),
('BT006', 'SF002', 'ST008', '2021-12-25'),
('BT007', 'SF006', 'ST007', '2021-12-26'),
('BT008', 'SF003', 'ST003', '2021-12-27'),
('BT009', 'SF010', 'ST010', '2021-12-28'),
('BT010', 'SF004', 'ST006', '2021-12-29'),
('BT011', 'SF009', 'ST006', '2021-12-30'),
('BT012', 'SF009', 'ST006', '2021-12-31'),
('BT013', 'SF005', 'ST005', '2022-01-01'),
('BT014', 'SF004', 'ST003', '2022-01-02'),
('BT015', 'SF004', 'ST009', '2022-01-03'),
('BT016', 'SF003', 'ST002', '2020-01-18'),
('BT017', 'SF010', 'ST006', '2020-01-18'),
('BT018', 'SF004', 'ST007', '2020-02-07');

INSERT INTO BorrowTransactionDetail (borrow_id, return_date, book_id)
VALUES
('BT001', GETDATE()+3, 'BK001'),
('BT001', GETDATE()+2, 'BK002'),
('BT001', GETDATE()+1, 'BK003'),
('BT002', GETDATE()+3, 'BK004'),
('BT002', GETDATE()+1, 'BK005'),
('BT003', GETDATE()+1, 'BK006'),
('BT003', GETDATE()+2, 'BK007'),
('BT003', GETDATE()+2, 'BK008'),
('BT003', GETDATE()+3, 'BK009'),
('BT003', GETDATE()+2, 'BK010'),
('BT004', GETDATE()+3, 'BK001'),
('BT004', GETDATE()+1, 'BK014'),
('BT005', GETDATE()+2, 'BK011'),
('BT006', GETDATE()+3, 'BK001'),
('BT006', GETDATE()+2, 'BK002'),
('BT006', GETDATE()+2, 'BK008'),
('BT006', GETDATE()+3, 'BK009'),
('BT006', GETDATE()+1, 'BK015'),
('BT007', GETDATE()+1, 'BK012'),
('BT007', GETDATE()+2, 'BK007'),
('BT008', GETDATE()+3, 'BK013'),
('BT009', GETDATE()+3, 'BK004'),
('BT010', GETDATE()+3, 'BK004'),
('BT010', GETDATE()+1, 'BK016'),
('BT010', GETDATE()+2, 'BK017'),
('BT011', GETDATE()+2, 'BK002'),
('BT012', GETDATE()+3, 'BK009'),
('BT013', GETDATE()+2, 'BK011'),
('BT013', GETDATE()+1, 'BK012'),
('BT013', GETDATE()+3, 'BK013'),
('BT013', GETDATE()+1, 'BK014'),
('BT013', GETDATE()+1, 'BK015'),
('BT014', GETDATE()+1, 'BK005'),
('BT014', GETDATE()+1, 'BK006'),
('BT015', GETDATE()+2, 'BK002'),
('BT015', GETDATE()+3, 'BK009'),
('BT016', GETDATE()+3, 'BK001'),
('BT017', GETDATE()+3, 'BK001'),
('BT018', GETDATE()+3, 'BK001');

--d).

SELECT * FROM Staff;

SELECT * FROM Donator;

SELECT * FROM Student;

SELECT * FROM BookCategories;

SELECT * FROM Book;

SELECT * FROM DonationTransaction;

SELECT * FROM DonationTransactionDetail;

SELECT * FROM BorrowTransaction;

SELECT * FROM BorrowTransactionDetail;

BEGIN TRAN
UPDATE BorrowTransaction
SET borrow_date = '2021-12-28'
WHERE staff_id LIKE 'SF002'
COMMIT

BEGIN TRAN
DELETE BorrowTransaction
WHERE staff_id = 'SF004'
ROLLBACK

SELECT *
	FROM BorrowTransaction BT JOIN
		BorrowTransactionDetail BTD
		ON BT.borrow_id = BTD.borrow_id
ORDER BY student_id ASC

SELECT *
	FROM DonationTransaction DT FULL OUTER JOIN
		DonationTransactionDetail DTD
		ON DT.donation_id = DTD.donation_id
WHERE staff_id = 'SF006'
ORDER BY quantity DESC

SELECT BT.borrow_id
	FROM BorrowTransaction BT
	JOIN BorrowTransactionDetail BTD
	ON BT.borrow_id = BTD.borrow_id
WHERE book_id = 'BK011'
		UNION
SELECT BT.borrow_id
	FROM BorrowTransaction BT
	JOIN BorrowTransactionDetail BTD
	ON BT.borrow_id = BTD.borrow_id
WHERE MONTH(borrow_date) > 3

SELECT *
	FROM DonationTransaction DT
	JOIN DonationTransactionDetail DTD
	ON DT.donation_id = DTD.donation_id
WHERE book_id = 'BK006'
		EXCEPT
SELECT *
	FROM DonationTransaction DT
	JOIN DonationTransactionDetail DTD
	ON DT.donation_id = DTD.donation_id
WHERE DAY(donation_date) >= 25

SELECT BT.borrow_id
	FROM BorrowTransaction BT
	JOIN BorrowTransactionDetail BTD
	ON BT.borrow_id = BTD.borrow_id
WHERE book_id = 'BK011'
		INTERSECT
SELECT BT.borrow_id
	FROM BorrowTransaction BT
	JOIN BorrowTransactionDetail BTD
	ON BT.borrow_id = BTD.borrow_id
WHERE MONTH(borrow_date) > 3

SELECT
	DT.donation_id,
	[MAXIMUM QUANTITY] = MAX(quantity),
	[MINIMUM QUANTITY] = MIN(quantity),
	[AVERAGE QUANTITY] = AVG(quantity)
FROM DonationTransaction 
DT JOIN DonationTransactionDetail DTD
ON DT.donation_id = DTD.donation_id
GROUP BY DT.donation_id

SELECT BT.borrow_id
	FROM BorrowTransaction BT
	JOIN BorrowTransactionDetail BTD
	ON BT.borrow_id = BTD.borrow_id
WHERE book_id IN ('BK001')

SELECT *
	FROM DonationTransactionDetail
WHERE EXISTS (
	SELECT * FROM DonationTransaction
	WHERE quantity = 23
)

SELECT * FROM DonationTransactionDetail
WHERE quantity > ANY (SELECT TOP(5) stock FROM Book)

SELECT * FROM DonationTransactionDetail
WHERE quantity > SOME (SELECT TOP(5) stock FROM Book)

SELECT * FROM DonationTransactionDetail
WHERE quantity > ALL (SELECT TOP(5) stock FROM Book)

SELECT *
	FROM DonationTransactionDetail DTD, Book,
		(SELECT Average = AVG(stock) FROM Book) AS ALIAS
WHERE DTD.book_id = Book.book_id AND stock > ALIAS.Average

--e). 

--1. Display StudentName, StudentAddress, BorrowTransactionID, BorrowTransactionDate, 
--   and number of books borrowed (obtained from the total number of books borrowed) 
--   for every borrow transaction happened in 2020 by student whose address ends with � Street�.

SELECT
	[StudentName] = student_name,
	[StudentAddress] = student_address,
	[BorrowTransactionID] = BT.borrow_id,
	[BorrowTransactionDate] = borrow_date,
	[Number of Books Borrowed] = COUNT(book_id)
FROM Student ST 
	JOIN BorrowTransaction BT
	ON ST.student_id = BT.student_id
	JOIN BorrowTransactionDetail BTD
	ON BT.borrow_id = BTD.borrow_id
WHERE YEAR(borrow_date) = '2020' AND student_address LIKE '% Street'
GROUP BY student_name, student_address, BT.borrow_id, borrow_date

--2. Display BookTitle, Publish Month (obtained from the month of the book publish date), BookCategoryName, 
--	 and Total Sum Donation (obtained from the total donation quantity) for each book whose category name 
--   contains �y� and published in an odd month. 

SELECT 
	[BookTitle] = book_title,
	[Publish Month] = MONTH(publish_date),
	[BookCategoryName] = category,
	[Total Sum Donation] = SUM(quantity)
FROM Book BK
	JOIN DonationTransactionDetail DT
	ON BK.book_id = DT.book_id
	JOIN BookCategories BC
	ON BK.book_category_id = BC.book_category_id
WHERE (category LIKE 'y%' OR category LIKE '%y%' OR category LIKE '%y') AND MONTH(publish_date) % 2 != 0
GROUP BY book_title, publish_date, category

-- 3. Display BorrowTransactionID, Borrow Transaction Date (obtained from BorrowTransactionDate with �dd mon yyyy� format), 
--    StudentName, Books Borrowed (obtained from the total number of borrowed books), and Average Book Rating (obtained from 
--    the average rating of borrowed books) for every borrow transaction whose student has �gmail� domain email and Average Book Rating more than 4.0.

SELECT 
	[BorrowTransactionID] = BT.borrow_id,
	[Borrow Transaction Date] = CONVERT(VARCHAR,borrow_date,106),
	[StudentName] = student_name,
	[Books Borrowed] = COUNT(BTD.book_id), 
	[Average Book Rating] = AVG(rating)
FROM BorrowTransaction BT 
	JOIN Student ST
	ON BT.student_id = ST.student_id
	JOIN BorrowTransactionDetail BTD
	ON BT.borrow_id = BTD.borrow_id
	JOIN Book BK
	ON BTD.book_id = BK.book_id
WHERE student_email LIKE '%gmail%'
GROUP BY BT.borrow_id, borrow_date, student_name
HAVING AVG(rating) > 4.0

-- 4. Display DonatorName (obtained from DonatorName and started with �Ms.�), DonationDate (obtained from DonationDate with �Mon dd, yyyy� format), 
--    Books Donated (obtained from the number of donated books), and Average Rating (obtained from the average rating of the donated books) for each 
--    donation happened in the first two weeks (inclusively between the 1st and the 14th day) from a female donator. 

SELECT
	[DonatorName] = 'Ms.' + donator_name,
	[DonationDate] = CONVERT(VARCHAR,donation_date,107),
	[Books Donated] = COUNT( DISTINCT quantity),
	[Average Rating] = AVG(rating)
FROM Donator DR
	JOIN DonationTransaction DT
	ON DR.donator_id = DT.donator_id
	JOIN DonationTransactionDetail DTD
	ON DT.donation_id = DTD.donation_id
	JOIN Book BK
	ON DTD.book_id = BK.book_id
WHERE donation_date BETWEEN '2020-07-10' AND '2020-07-24' AND donator_gender LIKE 'Female'
GROUP BY donator_name, donation_date

-- 5. Display DonatorName, DonationDate, StaffName, StaffGender, and StaffSalary (obtained from StaffSalary and started with �Rp.�) 
--    for every donation completed by staff whose salary is more than the average staff salary and its donator name consists of minimum 
--    two words. Sort the result by DonationDate in descending order. 
--    (alias subquery)

SELECT
	[DonatorName] = DR.donator_name,
	[DonationDate] = donation_date,
	[StaffName] = staff_name,
	[StaffGender] = staff_gender,
	[StaffSalary] = 'Rp.' + CONVERT(VARCHAR,staff_salary)
FROM Donator DR
	JOIN DonationTransaction DT
	ON DR.donator_id = DT.donator_id
	JOIN Staff SF
	ON DT.staff_id = SF.staff_id,
	(SELECT Average = AVG(staff_salary) FROM Staff)	AS A,
	(SELECT donator_name AS DonatorCheck
	 FROM Donator
	 WHERE donator_name LIKE '% %'
	 ) AS B	
WHERE staff_salary > A.Average AND DR.donator_name = B.DonatorCheck
ORDER BY donation_date DESC

--6. Display DonationID, BookTitle (obtained from removing all white spaces from BookTitle), Rating Percentage (obtained from multiplying 
--   the BookRating with 20 and added with �%� at the end), Quantity, and DonatorPhone for each donation with book rating more than the average 
--   rating and DonatorAddress consists of more than 15 characters. 
--   (alias subquery)

SELECT DISTINCT
	[DonationID] = DT.donation_id,
	[BookTitle] = book_title,
	[Rating Percentage] = CONVERT(VARCHAR, (20*rating)) + '%',
	[Quantity] = quantity,
	[DonatorPhone] = donator_phone_number
FROM DonationTransaction DT
	JOIN DonationTransactionDetail DTD
	ON DT.donation_id = DTD.donation_id
	JOIN Book BK
	ON DTD.book_id = BK.book_id
	JOIN Donator DR
	ON DT.donator_id = DR.donator_id,
	(SELECT AVG(rating) AS Average FROM Book) AS A,
	(SELECT donator_address AS DonatorAddressCheck
	 FROM Donator
	 WHERE LEN(donator_address) > 15
	 ) AS B	
WHERE rating > A.Average AND donator_address = B.DonatorAddressCheck

--7. Display BorrowTransactionID, Borrow Date (obtained from BorrowTransactionDate in �mm-dd-yyyy� format), 
--   Return Day (obtained from the day name of the return date), BookTitle, BookRating (obtained from BookRating followed by � star(s)�), 
--   and BookCategoryName for each borrow transaction which contains book(s) whose rating is equal to the minimum rating or the maximum 
--   rating of all available books while also have more than 10 stocks. Sort the result based on the BorrowTransactionID in descending order.
--   (alias subquery)

SELECT 
	[BorrowTransactionID] = BT.borrow_id,
	[Borrow Date] = CONVERT(VARCHAR,borrow_date,110),
	[Return Day] = DAY(borrow_date),
	[BookTitle] = book_title,
	[BookRating] = CONVERT(VARCHAR,rating) + ' star(s)',
	[BookCategoryName] = category
FROM BorrowTransaction BT
	JOIN BorrowTransactionDetail BTD
	ON BT.borrow_id = BTD.borrow_id
	JOIN Book BK
	ON BTD.book_id = BK.book_id
	JOIN BookCategories BC
	ON BK.book_category_id = BC.book_category_id,
	(SELECT MAX(rating) AS MaxRating FROM Book WHERE stock>10) AS A,
	(SELECT MIN(rating) AS MinRating FROM Book WHERE stock>10) AS B
WHERE rating = A.MaxRating OR rating = B.MinRating
ORDER BY BT.borrow_id DESC

--8 Display StudentName (obtained from StudentName added with �Mr. � at the beginning), StudentEmail (obtained by removing �.com� from StudentEmail), 
--  Books Borrowed (obtained from the total number of books borrowed) for each borrow transaction done by male student and served by staff whose salary 
--  is more than the average staff salary. Then, combine it with StudentName (obtained from StudentName added with �Ms. � at the beginning), 
--  StudentEmail (obtained by removing �.com� from StudentEmail), Books Borrowed (obtained from the total number of books borrowed) for each borrow transaction 
--  done by female student and served by staff whose salary is less than the average staff salary.
--  (alias subquery)

SELECT 
	[StudentName] = 'Mr. ' + student_name,
	[StudentEmail] = SUBSTRING(student_email, 1, LEN(student_email) - 4),
	[Books Borrowed] = COUNT(DISTINCT book_id)
FROM Student ST
	JOIN BorrowTransaction BT
	ON ST.student_id = BT.student_id
	JOIN BorrowTransactionDetail BTD
	ON BT.borrow_id = BTD.borrow_id
	JOIN Staff SF
	ON SF.staff_id = BT.staff_id,
	(SELECT student_gender AS GenderCheck
	 FROM Student
	 WHERE student_gender LIKE 'Male'
	 ) AS A,
	(SELECT AVG(staff_salary) AS Average FROM Staff) AS B
WHERE student_gender = A.GenderCheck AND staff_salary > B.Average
GROUP BY student_name, student_email
	UNION
SELECT 
	[StudentName] = 'Ms. ' + student_name,
	[StudentEmail] = SUBSTRING(student_email, 1, LEN(student_email) - 4),
	[Books Borrowed] = COUNT(DISTINCT book_id)
FROM Student ST
	JOIN BorrowTransaction BT
	ON ST.student_id = BT.student_id
	JOIN BorrowTransactionDetail BTD
	ON BT.borrow_id = BTD.borrow_id
	JOIN Staff SF
	ON SF.staff_id = BT.staff_id,
	(SELECT student_gender AS GenderCheck
	 FROM Student
	 WHERE student_gender LIKE 'Female'
	 ) AS A,
	(SELECT AVG(staff_salary) AS Average FROM Staff) AS B
WHERE student_gender = A.GenderCheck AND staff_salary < B.Average
GROUP BY student_name, student_email

-- 9. Create a view named �ViewDonationDetail� to display DonatorName, Donation Transaction (obtained from the number of donation transaction), 
--    Average Quantity (obtained from the average donation quantity) for each donation done by donator whose address ended with � Street� or � Avenue� 
--    and Donation Transaction more than 1.
GO
CREATE VIEW ViewDonationDetail
AS
SELECT
	[Donation Transaction] = COUNT(DISTINCT DT.donation_id),
	[Average Quantity] = AVG(quantity)
FROM DonationTransaction DT
	JOIN DonationTransactionDetail DTD
	ON DT.donation_id = DTD.donation_id
	JOIN Donator DR
	ON DR.donator_id = DT.donator_id,
	(SELECT donator_address AS AddressCheck
	 FROM Donator
	 WHERE donator_address LIKE '% Street' OR donator_address LIKE '% Avenue'
	 ) AS A
WHERE donator_address = A.AddressCheck
HAVING COUNT(DISTINCT DT.donation_id) > 1


-- 10. Create a view named �ViewStudentBorrowingData� to display StudentName, Borrow Transaction (obtained from the total number of transaction), 
--     and Average Duration (obtained from the average different days between the borrow date and return date) for each borrow transaction done by 
--     male student whose email contains �yahoo�.
GO
CREATE VIEW ViewStudentBorrowingData
AS
SELECT 
	[StudentName] = student_name,
	[Borrow Transaction] = COUNT(DISTINCT BT.borrow_id),
	[Average Duration] = AVG(DATEDIFF(DAY,borrow_date,return_date))
FROM Student ST
	JOIN BorrowTransaction BT
	ON ST.student_id = BT.student_id
	JOIN BorrowTransactionDetail BTD
	ON BT.borrow_id = BTD.borrow_id,
	(SELECT student_gender AS StudentCheck
	 FROM Student
	 WHERE student_gender LIKE 'Male'
	 ) AS A
WHERE student_gender = A.StudentCheck AND student_email LIKE '%yahoo%'
GROUP BY student_name



	






	
	








































