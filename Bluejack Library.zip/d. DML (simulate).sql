--d).

SELECT * FROM Staff;

SELECT * FROM Donator;

SELECT * FROM Student;

SELECT * FROM BookCategories;

SELECT * FROM Book;

SELECT * FROM DonationTransaction;

SELECT * FROM DonationTransactionDetail;

SELECT * FROM BorrowTransaction;

SELECT * FROM BorrowTransactionDetail;

BEGIN TRAN
UPDATE BorrowTransaction
SET borrow_date = '2021-12-28'
WHERE staff_id LIKE 'SF002'
COMMIT

BEGIN TRAN
DELETE BorrowTransaction
WHERE staff_id = 'SF004'
ROLLBACK

SELECT *
	FROM BorrowTransaction BT JOIN
		BorrowTransactionDetail BTD
		ON BT.borrow_id = BTD.borrow_id
ORDER BY student_id ASC

SELECT *
	FROM DonationTransaction DT FULL OUTER JOIN
		DonationTransactionDetail DTD
		ON DT.donation_id = DTD.donation_id
WHERE staff_id = 'SF006'
ORDER BY quantity DESC

SELECT BT.borrow_id
	FROM BorrowTransaction BT
	JOIN BorrowTransactionDetail BTD
	ON BT.borrow_id = BTD.borrow_id
WHERE book_id = 'BK011'
		UNION
SELECT BT.borrow_id
	FROM BorrowTransaction BT
	JOIN BorrowTransactionDetail BTD
	ON BT.borrow_id = BTD.borrow_id
WHERE MONTH(borrow_date) > 3

SELECT *
	FROM DonationTransaction DT
	JOIN DonationTransactionDetail DTD
	ON DT.donation_id = DTD.donation_id
WHERE book_id = 'BK006'
		EXCEPT
SELECT *
	FROM DonationTransaction DT
	JOIN DonationTransactionDetail DTD
	ON DT.donation_id = DTD.donation_id
WHERE DAY(donation_date) >= 25

SELECT BT.borrow_id
	FROM BorrowTransaction BT
	JOIN BorrowTransactionDetail BTD
	ON BT.borrow_id = BTD.borrow_id
WHERE book_id = 'BK011'
		INTERSECT
SELECT BT.borrow_id
	FROM BorrowTransaction BT
	JOIN BorrowTransactionDetail BTD
	ON BT.borrow_id = BTD.borrow_id
WHERE MONTH(borrow_date) > 3

SELECT
	DT.donation_id,
	[MAXIMUM QUANTITY] = MAX(quantity),
	[MINIMUM QUANTITY] = MIN(quantity),
	[AVERAGE QUANTITY] = AVG(quantity)
FROM DonationTransaction 
DT JOIN DonationTransactionDetail DTD
ON DT.donation_id = DTD.donation_id
GROUP BY DT.donation_id

SELECT BT.borrow_id
	FROM BorrowTransaction BT
	JOIN BorrowTransactionDetail BTD
	ON BT.borrow_id = BTD.borrow_id
WHERE book_id IN ('BK001')

SELECT *
	FROM DonationTransactionDetail
WHERE EXISTS (
	SELECT * FROM DonationTransaction
	WHERE quantity = 23
)

SELECT * FROM DonationTransactionDetail
WHERE quantity > ANY (SELECT TOP(5) stock FROM Book)

SELECT * FROM DonationTransactionDetail
WHERE quantity > SOME (SELECT TOP(5) stock FROM Book)

SELECT * FROM DonationTransactionDetail
WHERE quantity > ALL (SELECT TOP(5) stock FROM Book)

SELECT *
	FROM DonationTransactionDetail DTD, Book,
		(SELECT Average = AVG(stock) FROM Book) AS ALIAS
WHERE DTD.book_id = Book.book_id AND stock > ALIAS.Average
