--b).
CREATE TABLE Staff(
	staff_id CHAR(5) PRIMARY KEY NOT NULL,
	staff_name VARCHAR(50) NOT NULL,
	staff_gender VARCHAR(20) NOT NULL,
	staff_address VARCHAR(50) NOT NULL,
	staff_phone VARCHAR(15) NOT NULL,
	staff_salary INT NOT NULL,
	CONSTRAINT CheckStaffID CHECK(staff_id LIKE 'SF[0-9][0-9][0-9]'),
	CONSTRAINT CheckStaffGender CHECK(staff_gender = 'Male' OR staff_gender = 'Female' ),
	CONSTRAINT CheckStaffPhone CHECK(staff_phone LIKE '+62%')
);

CREATE TABLE Donator (
	donator_id CHAR(5) PRIMARY KEY NOT NULL,
	donator_name VARCHAR(50) NOT NULL,
	donator_gender VARCHAR(20) NOT NULL,
	donator_address VARCHAR(50) NOT NULL,
	donator_phone_number VARCHAR(15) NOT NULL,
	CONSTRAINT CheckDonatorID CHECK(donator_id LIKE 'DR[0-9][0-9][0-9]'),
	CONSTRAINT CheckDonatorName CHECK(LEN(donator_name) > 1)
);

CREATE TABLE Student(
	student_id CHAR(5) PRIMARY KEY NOT NULL,
	student_name VARCHAR(50) NOT NULL,
	student_gender VARCHAR(20) NOT NULL,
	student_address VARCHAR(50) NOT NULL,
	student_email VARCHAR(50) NOT NULL,
	CONSTRAINT CheckStudentID CHECK(student_id LIKE 'ST[0-9][0-9][0-9]'),
	CONSTRAINT CheckStudentGender CHECK(student_gender = 'Male' OR student_gender = 'Female' ),
	CONSTRAINT CheckStudentEmail CHECK(student_email LIKE '%@%')
);

CREATE TABLE BookCategories (
	book_category_id CHAR(5) PRIMARY KEY NOT NULL,
	category VARCHAR(20) NOT NULL,
	CONSTRAINT CheckBookCategoriesID CHECK(book_category_id LIKE 'BC[0-9][0-9][0-9]')
);

CREATE TABLE Book(
	book_id CHAR(5) PRIMARY KEY NOT NULL,
	book_category_id CHAR(5) FOREIGN KEY (book_category_id) REFERENCES BookCategories (book_category_id) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	book_title VARCHAR(50) NOT NULL,
	publish_date DATE NOT NULL,
	stock INT NOT NULL,
	rating FLOAT NOT NULL,
	CONSTRAINT CheckBookID CHECK(book_id LIKE 'BK[0-9][0-9][0-9]'),
	CONSTRAINT CheckBookPublishYear CHECK (YEAR(publish_date) > 2011)
);

CREATE TABLE BorrowTransaction(
	borrow_id CHAR(5) PRIMARY KEY NOT NULL,
	student_id CHAR(5) FOREIGN KEY (student_id) REFERENCES Student (student_id) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	staff_id CHAR(5) FOREIGN KEY (staff_id) REFERENCES Staff (staff_id) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	borrow_date DATE NOT NULL,
	CONSTRAINT CheckBorrowTransactionID CHECK(borrow_id LIKE 'BT[0-9][0-9][0-9]')
);

CREATE TABLE BorrowTransactionDetail(
	borrow_id CHAR(5) FOREIGN KEY REFERENCES BorrowTransaction(borrow_id) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	book_id CHAR(5) FOREIGN KEY (book_id) REFERENCES Book (book_id) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	return_date DATE NOT NULL,
	PRIMARY KEY(borrow_id, book_id),
	CONSTRAINT CheckReturnDate CHECK(return_date > GETDATE())
);

CREATE TABLE DonationTransaction(
	donation_id CHAR(5) PRIMARY KEY NOT NULL,
	staff_id CHAR(5) FOREIGN KEY (staff_id) REFERENCES Staff (staff_id) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	donator_id CHAR(5) FOREIGN KEY (donator_id) REFERENCES Donator (donator_id) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	donation_date DATE NOT NULL,
	CONSTRAINT CheckDonationTransactionID CHECK(donation_id LIKE 'DT[0-9][0-9][0-9]'),
);

CREATE TABLE DonationTransactionDetail(
	donation_id CHAR(5) FOREIGN KEY REFERENCES DonationTransaction(donation_id) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	book_id CHAR(5) FOREIGN KEY (book_id) REFERENCES Book (book_id) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	quantity INT NOT NULL,
	PRIMARY KEY(donation_id, book_id),
	CONSTRAINT CheckQuantity CHECK(quantity BETWEEN 10 AND 500)
);